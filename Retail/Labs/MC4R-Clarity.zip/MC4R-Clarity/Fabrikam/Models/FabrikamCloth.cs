using System.ComponentModel.DataAnnotations;

namespace Fabrikam.Models;

public class FabrikamCloth
{
    public int Id { get; set; }

    [Required]
    public string? CType { get; set; }
    public ClothSize Size { get; set; }
    public ClothColor Color { get; set; }
    public bool InStock { get; set; }

    [Range(0.01, 9999.99)]
    public decimal Price { get; set; }
}

public enum ClothSize { XSmall, Small, Medium, Large, XLarge, XXLarge }
public enum ClothColor { White, Yellow, Blue, Green, Red, Brown, Purple, Black, Gray, Pink, Orange }