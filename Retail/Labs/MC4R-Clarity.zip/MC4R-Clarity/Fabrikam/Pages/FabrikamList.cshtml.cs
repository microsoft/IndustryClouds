using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Fabrikam.Models;
using Fabrikam.Services;

namespace Fabrikam.Pages
{
    public class FabrikamClothModel : PageModel
    {

        public void OnGet()
        {
            cloths = FabrikamService.GetAll();
        }
        public List<FabrikamCloth> cloths = new();
        public string InStockText(FabrikamCloth cloth)
        {
            if (cloth.InStock)
                return "In Stock";
            return "Out Of Stock";
        }
        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }
            FabrikamService.Add(NewCloth);
            return RedirectToAction("Get");
        }
        [BindProperty]
        public FabrikamCloth NewCloth { get; set; } = new();
        public IActionResult OnPostDelete(int id)
        {
            FabrikamService.Delete(id);
            return RedirectToAction("Get");
        }

    }

}
