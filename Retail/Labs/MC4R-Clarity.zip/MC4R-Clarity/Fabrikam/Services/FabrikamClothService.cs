using Fabrikam.Models;

namespace Fabrikam.Services;
public static class FabrikamService
{
    static List<FabrikamCloth> Cloths { get; }
    static int nextId = 3;
    static FabrikamService()
    {
        Cloths = new List<FabrikamCloth>
                {
                    new FabrikamCloth { Id = 1, CType = "Trousers",   Size = ClothSize.Large,  Color = ClothColor.Black  ,   InStock = false , Price=20.00M },
                    new FabrikamCloth { Id = 2, CType = "Jeans",      Size = ClothSize.Small,  Color = ClothColor.Blue   ,   InStock = true  , Price=15.00M},
                    new FabrikamCloth { Id = 3, CType = "T-Shirt",    Size = ClothSize.XLarge, Color = ClothColor.Black  ,   InStock = false , Price=15.00M },
                    new FabrikamCloth { Id = 4, CType = "Skirt",      Size = ClothSize.Small,  Color = ClothColor.Yellow ,   InStock = false , Price=21.00M },
                    new FabrikamCloth { Id = 5, CType = "T-Shirt",    Size = ClothSize.Small,  Color = ClothColor.White  ,   InStock = true  , Price=14.00M},
                    new FabrikamCloth { Id = 6, CType = "Skirt",      Size = ClothSize.XSmall, Color = ClothColor.Black  ,   InStock = false , Price=16.00M },
                    new FabrikamCloth { Id = 7, CType = "Jacket",     Size = ClothSize.Large,  Color = ClothColor.Brown  ,   InStock = true  , Price=18.00M}
                };
    }

    public static List<FabrikamCloth> GetAll() => Cloths ;

    public static FabrikamCloth? Get(int id) => Cloths.FirstOrDefault(p => p.Id == id);

    public static void Add(FabrikamCloth cloth)
    {
        cloth.Id = nextId++;
        Cloths.Add(cloth);
    }

    public static void Delete(int id)
    {
        var cloth = Get(id);
        if (cloth is null)
            return;

        Cloths.Remove(cloth);
    }

    public static void Update(FabrikamCloth cloth)
    {
        var index = Cloths.FindIndex(p => p.Id == cloth.Id);
        if (index == -1)
            return;

        Cloths[index] = cloth;
    }
                }